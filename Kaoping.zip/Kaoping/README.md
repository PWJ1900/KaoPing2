# kaopingxiton

> A Vue.js project

# 开发其布置
  1、页面放在pages下<br>
	2、有公共数据或方法可放在store文件夹下配合vuex使用<br>
	3、使用较多的js代码放在utils文件夹里复用<br>
	4、有公用的组件自定义显示的放在components下<br>
	5、静态文件可以放在assets下<br>
	6、页面及其效果文件放在css里

	总之先自己吧对应页面功能做一下
## Build Setup

``` bash
# install dependencies
npm install

# serve with hot reload at localhost:8080
npm run dev

# build for production with minification
npm run build

# build for production and view the bundle analyzer report
npm run build --report
```

For a detailed explanation on how things work, check out the [guide](http://vuejs-templates.github.io/webpack/) and [docs for vue-loader](http://vuejs.github.io/vue-loader).
