<template>

  <div>
    <el-row>
      <el-button>推荐结果</el-button>
    </el-row>

  </div>
</template>
<script>
export default {

}
</script>