<template>

  <div>
    <el-row>
      <el-button>人数设置</el-button>
    </el-row>

  </div>
</template>
<script>
export default {

}
</script>