<template>

  <div>
    <el-row>
      <el-button>数据统计</el-button>
    </el-row>

  </div>
</template>
<script>
export default {

}
</script>