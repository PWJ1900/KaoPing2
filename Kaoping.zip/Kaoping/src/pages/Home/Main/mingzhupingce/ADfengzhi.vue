<template>

  <div>
    <el-row>
      <el-button>A~D分值</el-button>
    </el-row>

  </div>
</template>
<script>
export default {

}
</script>