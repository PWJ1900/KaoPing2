<template>

  <div>
    <el-row>
      <el-button>指标体系</el-button>
    </el-row>

  </div>
</template>
<script>
export default {

}
</script>