<template>

  <div>
    <el-row>
      <el-button>数据上报</el-button>
    </el-row>

  </div>
</template>
<script>
export default {

}
</script>