<template>

  <div>
    <el-row>
      <el-button>等级统计</el-button>
    </el-row>

  </div>
</template>
<script>
export default {

}
</script>