<template>

  <div>
    <el-row>
      <el-button>身份类型</el-button>
    </el-row>

  </div>
</template>
<script>
export default {

}
</script>