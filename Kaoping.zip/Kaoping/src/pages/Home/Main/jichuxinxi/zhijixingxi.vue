<template>

  <div>
    <el-row>
      <el-button>职级信息</el-button>
    </el-row>

  </div>
</template>
<script>
export default {

}
</script>