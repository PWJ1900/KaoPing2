<template>

  <div>
    <el-row>
      <el-button>数据删除</el-button>
    </el-row>

  </div>
</template>
<script>
export default {

}
</script>