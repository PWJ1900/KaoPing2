<template>

  <div>
    <el-row>
      <el-button>系统初始化</el-button>
    </el-row>

  </div>
</template>
<script>
export default {

}
</script>